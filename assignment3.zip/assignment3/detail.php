<?php

include('functions.php');
$members=jsonToArray('data.json');

if(!isset($_GET['id'])){
	echo 'Please enter the id of a member or visit the <a href="index.php">index page</a>.';
	die();
}
if($_GET['id']<0 || $_GET['id']>count($members)-1){
	echo 'Please enter the id of a member or visit the <a href="index.php">index page</a>.';
	die();
}

$title=$members[$_GET['id']]['animal'].'-'.$members[$_GET['id']]['name'];
require('header.php');
?>

<h1><?= $members[$_GET['id']]['animal'].' - '.$members[$_GET['id']]['name'] ?></h1>
		<p><?= $members[$_GET['id']]['age'] ?> old</p>
		<img src="<?= $members[$_GET['id']]['picture'] ?>" width="500" />
		<p><?= $members[$_GET['id']]['bio'] ?></p>