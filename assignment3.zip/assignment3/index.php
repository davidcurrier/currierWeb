<?php
include('functions.php');
$members=jsonToArray('data.json');

$title='Pet Adoption';
require('header.php');
printHeader($title);
?>
<h1>Pet Adoption</h1>
<?php
	for($i=0;$i<count($members);$i++){
		showItem($i,$members[$i]['animal'].' - '. $members[$i]['name'],$members[$i]['picture']);
		echo '<hr>';
	}