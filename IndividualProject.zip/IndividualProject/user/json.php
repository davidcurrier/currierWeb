<?php

/*
$beatles=readJSON('beatles.json');
$beatles[0]['last_name']='Lennon';
echo '<pre>';
print_r($beatles);
writeJSON('beatles.json',$beatles);
*/

//$index=$_GET['index'];
//unset($_GET['index']);
//echo '<pre>';
//$allowed_fields=['name','last_name','age','dob','picture','address'];
//print_r(filterInput($_GET,$allowed_fields));
//echo '<hr>';
//print_r($_GET);

//modifyJSON('beatles.json',$_GET,$index);

function filterInput($data,$allowed_fields){
	for($i=0;$i<count(array_keys($data));$i++)
		if(!in_array(array_keys($data)[$i],$allowed_fields)) unset($data[array_keys($data)[$i]]);
	return $data;
}

function writeJSON($file,$data,$mode='w'){

       if(!isset($data))return;

       if($mode=='a'){

              if(file_exists($file)) $array=readJSON($file);

              if(!is_array($array)) $array=[];

              $array=$data;

       }else $array=$data;

       $h=fopen($file,'w+');

       fwrite($h,json_encode($array,JSON_PRETTY_PRINT));

       fclose($h);

}

function modifyJSON($file, $data, $index, $overwrite=false){

       if(!file_exists($file) || !isset($data) || !isset($index)) return false;

       $input=readJSON($file);

       if(!is_array($input) || !isset($array[$index])) return false;

       $input[$index]=$overwrite ? $data : array_merge($input[$index], $data);

       writeJSON($file,$input);

       return true;

}

function deleteJSON($file, $index=null){

       if(!file_exists($file)) return false;

       if(!isset($index)){

              unlink($file);

              return true;

       }

       $input=readJSON($file);

       if(!is_array($input) || !isset($input[$index])) return false;

       unset($input[$index]);

       writeJSON($file, $input);

}

function readJSON($file,$index=null){
	if(!file_exists($file)) return [];
	$output = json_decode(file_get_contents($file), true);
	if(count($output) == 0) return [];
	return !isset($index) ? $output : (isset($output[$index]) ? $output[$index] : null);
	/*$h=fopen($file,'r');
	$output='';
	while(!feof($h)) $output.=fgets($h);
	fclose($h);
	$output=json_decode($output,true);
	return !isset($index) ? $output : (isset($output[$index]) ? $output[$index] : null);*/
}

