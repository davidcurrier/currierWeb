<?php

$companyName = 'Food Santa';
//require_once('data.php');
//$memberList = file_get_contents ('data.json');
//$members = json_decode($memberList,true);

function jsonToArray(string $file) {
	return json_decode(file_get_contents($file), true);
}

$members = jsonToArray('../data.json');
require('../header.php');
?>

		<?php
		
		echo '<h1>'.$members[$_GET['id']]['firstname'].' '.$members[$_GET['id']]['lastname'].'</h1>';
		
		echo '
		
		<img class = "profilepic" src=" ../'.$members[$_GET['id']]['profile_picture'].' " width="250" />
		<p> '.$members[$_GET['id']]['bio'] .' </p>
		
		
		<p>'.$members[$_GET['id']]['date_of_birth'].'</p>
		<p> Location: '.$members[$_GET['id']]['location'].' </p>';
		
		
		echo '<h3> Item Listings</h3>';
		
		echo '<h5>'.$members[$_GET['id']]['food_name'].'</h5>';
	
		echo ' <img class = "profilepic" src=" ../'.$members[$_GET['id']]['food_picture'].' " width="75" /> <br><br>';
		
		
		echo ''.$members[$_GET['id']]['food_description'].' <br><br>';
		
		echo '<a href="create.php?id='.$_GET['id'].'">Create listing</a> <br><br>';
		
		echo '<a href="delete.php?id='.$_GET['id'].'">Delete listing</a> <br><br>';

		
		
		
		
		require ('../footer.php');
		
		?>