<?php
// REQUIRE JSON LIBRARY require_once('json.php');

// CHECK IF THERE IS SOME DATA IN POST
// IF SO, writeJSON('maintenance.json',$_POST);
//ELSE DISPLAY FORM BELOW

require_once('json.php');
if(!count($_POST) == 0 )
{
	
	/*$formdata = array(
	      'issue'=> $_POST['issue'],
	      'room'=> $_POST['room'],
	      'urgency'=>$_POST['urgency']
	      
	   );
	   */
	   
	$jsondata = file_get_contents('../data.json');
	
	$arr_data = json_decode($jsondata, true);

	array_push($arr_data,$_POST);
	
	$jsondata = json_encode($arr_data, JSON_PRETTY_PRINT);

	file_put_contents('../data.json', $jsondata);
	//writeJSON('maintenance.json',$_POST);
}
else
{
?>
<html>
<form action="create.php" method="POST">
First Name
<input type="text" name="firstname"><br>
Last Name
<input type="text" name="lastname"><br>
Status
<input type="text" name="status"><br>
Date of Birth
<input type="text" name="date_of_birth"><br>
Bio
<input type="text" name="bio"><br>
Location
<input type="text" name="location"><br>
Profile Picture
<input type="text" name="profile_picture"><br>
Email
<input type="text" name="email"><br>
Food Picture
<input type="text" name="food_picture"><br>
Food Name
<input type="text" name="food_name"><br>
Food Description
<input type="text" name="food_description"><br>
Distace
<input type="text" name="distace"><br>

<button type="submit" value="Submit">Submit</button>
</form>
</html>
<?php
}
require('../footer.php');

?>