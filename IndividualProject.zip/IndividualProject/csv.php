<?php

/*
$csv='Will;Sie';
writeCSV('profile.csv',$csv);
$csv='Gordon;Ramsay';
writeCSV('profile.csv',$csv);
*/

echo '<pre>';
print_r(readCSV('profile.csv'));
print_r(filterInput($_GET,$allowed_fields));

$allowed_fields=['firstname','lastname','date_of_birth','profile_picture','location','email'];

function filterInput($data,$allowed_fields){
	for($i=0;$i<count(array_keys($data));$i++)
		if(!in_array(array_keys($data)[$i],$allowed_fields)) unset($data[array_keys($data)[$i]]);
	return $data;
}

function writeCSV($file,$data){
	$h=fopen($file,file_exists($file) ? 'a' : 'w+');
	fwrite($h,$data. "\n" /* PHP_EOL */);
	fclose($h);
}

function readCSV($file){
	$h=fopen($file,'r');
	$output='';
	while(!feof($h))
		$output.=fgets($h);
	fclose($h);
	$output=explode("\n",$output);
	unset($output[count($output)-1]);
	for($i=0;$i<count($output);$i++) 
		$output[$i]=explode(';',$output[$i]);
	return $output;	
}
	
function modifyCSV($file,$data,$index){
	$input=readCSV($file);
	$input[$index]=array_merge($input[$index],$data);
	writeCSV($file,$input);
}

function deleteCSV($file,$index){
	$input=readCSV($file);
	unset($input[$index]);
	writeCSV($file,$input);
}

?>