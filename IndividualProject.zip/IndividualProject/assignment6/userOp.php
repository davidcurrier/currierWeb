<?php

class userOperations
{
	public class create_($id)
	{
		echo '<a href="create.php?id='.$_GET['id'].'">Create listing</a> <br><br>';

		
	}
	
	public class delete_($id)
	{
		
		echo '<a href="delete.php?id='.$_GET['id'].'">Delete listing</a> <br><br>';

	}
	
	public class modify_($id)
	{
		
		echo '<a href="modfy.php?id='.$_GET['id'].'">Modify listing</a> <br><br>';

		
	}
}