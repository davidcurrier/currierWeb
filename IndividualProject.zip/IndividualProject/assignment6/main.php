<?php

class user()
{
	$firstName;
	$lastName;
	$status;
	$DOB;
	$bio;
	$location;
	$profilePic;
	$email;
	$foodPic;
	$foodName;
	$foodDescription;
	$distance;
	
	
	
	
}