<?php

$members = file_get_contents ('members.json');

echo $members;
echo '<hr>';

$members_array = json_decode($members, true);

echo '<pre>';
print_r($members_array);
echo '<hr>';
foreach($members_array

?>