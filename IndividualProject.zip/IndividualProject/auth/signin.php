<?php

session_start();
require_once('auth_library.php');
require ('../header.php');
if(is_logged()) header('location: members.php');
$title = 'Food Santa';
echo '<h1 class="headlines">'.$title.'<img src ="../image/logofinal.png" width="200"> </h1>';
printHeader($title);
/*
1. show signin form [DONE]
2. when the user submits the data we:
 2.1 we check if the email is there and it's valid
 2.2 we check if the password is there and it's valid
 2.3 check if email is in database
 2.4 check if the password matches the password entered by the user: https://www.php.net/manual/en/function.password-verify.php
 2.5 we congratulate the user on their life achievement
*/

if(count($_POST)>0){ // when user submits form:
	$error=signin('username.json','user/email');
	if(isset($error{0})) echo $error;
	else echo 'Successful';
}
?>


<h1>SIGN IN</h1>
	
<form action="signin.php" method="POST">
	<label for="email">Email:</label><br>
	<input type="email" id="email" name="email" value="" required><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password" value="" required minlength="8"><br>
	<input type="submit" value="Submit">
</form>

<?php
		require('../footer.php');
?>