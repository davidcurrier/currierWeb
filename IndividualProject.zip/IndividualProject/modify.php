<?php
// REQUIRE JSON LIBRARY require_once('json.php');

// CHECK IF THERE IS SOME DATA IN POST
// IF SO, modifyJSON('data.json',$_POST,$_GET['id']);
// ELSE
// $request=readJSON('data.json',$_GET['id']);

require ('header.php');
$title = 'Food Santa';
echo '<h1 class="headlines">'.$title.'<img src ="image/logofinal.png" width="200"> </h1>';
printHeader($title);
?>



<form action="create.php" method="POST">
	<label for="firstname">First Name:</label><br>
	<input type="text" id="firstname" name="firstname" value=""> <?= $request['firstName'] ?><br>
	<label for="lastname">Last name:</label><br>
	<input type="text" id="lastname" name="lastname" value=""><?= $request['lastName'] ?><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password" value=""> <?= $request['password'] ?><br>
	<label for="date_of_birth">Date of Birth:</label><br>
	<input type="datetime-local" id="date_of_birth" name="date_of_birth" value=""> <?= $request['date_of_birth'] ?><br>
	<label for="location">Location:</label><br>
	<input type="text" id="location" name="location" value=""> <?= $request['location'] ?><br>
	<label for="email">Email:</label><br>
	<input type="email" id="email" name="email" value=""> <?= $request['email'] ?><br>
	<label for="bio">About you:</label><br>
	<textarea rows="5" cols="49" type="text" id="bio" name="bio" value=""><?= $request['bio'] ?></textarea><br>
	<input type="submit" value="Submit">

</form>
<?php
		require('footer.php');
?>