<?php

$root = $_SERVER['DOCUMENT_ROOT'];

?>