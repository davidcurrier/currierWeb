<?php

$members=[
	[
		'firstname'=>'Will',
		'lastname'=>'Sie',
		'date_of_birth'=>'18 May 1980',
		'bio'=>'Will Sie is a passionte home chef who is ServSafe Food Handler certified and has 15 years of of work experience in the Foodservice industry',
		'location'=>'22 Woodland Hills Dr. #8, Southgate, KY.',
		'profile_picture'=>'image/will2.jpg',
		'food_picture'=>'image/cake.jpg',
		'food_description'=>'Double Chocolate Espresso Cake',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star checked',
		'star_rating5'=>'fa fa-star'
		
	],
	[
		'firstname'=>'Gordon',
		'lastname'=>'Ramsay',
		'date_of_birth'=>'8 November 1966',
		'bio'=>'Internationally renowned, multi-Michelin starred chef Gordon Ramsay has opened a string of successful restaurants across the globe, from the UK and France to Singapore and Hong Kong, to the United States. Gordon has also become a star of the small screen both in the UK and internationally, with shows such as Kitchen Nightmares, Hell’s Kitchen, Hotel Hell and MasterChef US.',
		'location'=>'22 Woodland Hills Dr. #9, Southgate, KY.',
		'profile_picture'=>'image/gordonramsay.jpg',
		'food_picture'=>'https://pbs.twimg.com/media/DH8PLn2XkAAX6YO.jpg:large',
		'food_description'=>'Best Beef Wellington!',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star checked',
		'star_rating5'=>'fa fa-star checked'
	],
	[
		'firstname'=>'Kroger',
		'lastname'=>'Pickup',
		'date_of_birth'=>'1883',
		'bio'=>'Pickup is an online ordering service from Kroger. Now you can shop online for the products you need and pick up your order at the store from the convenience of your car! Our Associates will even bring out your order and load it into your car.',
		'location'=>'22 Woodland Hills Dr. #10, Southgate, KY.',
		'profile_picture'=>'image/kroger.jpg',
		'email'=>'Stocktransfer@eq-us.com',
		'food_picture'=>'https://www.kroger.com/product/images/medium/front/0000000004011',
		'food_description'=>'Bananas - 5 days shelf life',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star checked',
		'star_rating5'=>'fa fa-star'
	],
	[
		'firstname'=>'Selena',
		'lastname'=>'Gomez',
		'date_of_birth'=>'22 July 1992',
		'bio'=>'Actress and singer Selena Gomez was born on July 22, 1992 in Grand Prairie, Texas. She is the daughter of Mandy Teefey and Ricardo Gomez. Her mother is of part Italian ancestry, and her father is of Mexican descent. She was named after Tejano singer, Selena.',
		'location'=>'22 Woodland Hills Dr. #8, Southgate, KY.',
		'profile_picture'=>'https://www.usmagazine.com/wp-content/uploads/2018/02/selena-gomez-twitter-2010.jpg?w=1000',
		'email'=>'selenagomez@hollywoodrecords.com',
		'food_picture'=>'https://cdn.vox-cdn.com/thumbor/xYTHdUTKDeo4x_B6wT5-EzmdcVc=/0x0:5472x3648/1220x813/filters:focal(2299x1387:3173x2261):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/65747830/shutterstock_1413240503.0.jpg',
		'food_description'=>'5 extra burgers, Bieber ordered too many for our date night !',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star checked',
		'star_rating5'=>'fa fa-star checked'
	]
];


if(!isset($_GET['id'])){
	echo 'Please enter the id of a member or visit the <a href="index.php">index page</a>.';
	die();
}
if($_GET['id']<0 || $_GET['id']>count($members)-1){
	echo 'Please enter the id of a member or visit the <a href="index.php">index page</a>.';
	die();
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


	<!-- Add icon library for star rating-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title><?= $members[$_GET['id']]['firstname'].' '.$members[$_GET['id']]['lastname'] ?></title>
	<style>
		.profilepic {
					align: center;
					max-width: 30%;
					height: auto;
					border-radius: 50%;
					padding: 20px 10px 20px 10px;
					}
		.checked	{color:orange;}
	</style>
  </head>
  <body>
	  <div class="container">
		<?php
		
		echo '<h1>'.$members[$_GET['id']]['firstname'].' '.$members[$_GET['id']]['lastname'].'</h1>';
		
		$rating = 0;
		for($j=1; $j<6; $j++){
			if (($members[$_GET['id']]['star_rating'.$j]) == 'fa fa-star checked'){
				$rating++;}
				
				echo '<span class="'.$members[$_GET['id']]['star_rating'.$j].'"></span>' ;
		} 
				echo '&nbsp &nbsp ('.$rating . ')';	
		
		echo '
		<p>'.$members[$_GET['id']]['date_of_birth'].'</p>
		<img class = "profilepic" src=" '.$members[$_GET['id']]['profile_picture'].' " width="500" />
		<p> '.$members[$_GET['id']]['bio'] .' </p>
		<p> Location: '.$members[$_GET['id']]['location'].' </p>';
		
		
		?>
	</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>