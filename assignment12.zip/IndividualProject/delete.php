<?php

// REQUIRE JSON LIBRARY require_once('json.php');
deleteJSON('data.json',$_GET['id']);

?>