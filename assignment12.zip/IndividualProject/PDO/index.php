<?php
$settings=[
	'host'=>'localhost',
	'db'=>'individualproject',
	'user'=>'root',
	'password'=>''
];

$opt=[
	PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES=>false,
];
$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',$settings['user'],$settings['password']);
//index
$result = $pdo -> query('SELECT ID,firstname FROM user');
echo'<table border="1">';
while($record = $result->fetch()){
	echo'<tr><td>'.$record['ID'].'</td><td>'.$record['firstname'].'</td></tr>';
	//print_r($record);
	//echo '<hr>';
}
echo '</table>';
echo '</hr>';
//detail
$result = $pdo -> query('SELECT * FROM user WHERE ID = 1');
if($result->rowCount()==0) echo '<p>There is no result matching the query</p>';
$record=$result->fetch();
echo '<h1>'.$record['firstname'].'</h1>';
echo '<p>'.$record['bio'].'</p>';

//create
/*$pdo->query('INSERT INTO user(firstname,lastname,status,dateofbirth,bio,location,profilepic,
email,foodpic,foodname,fooddescription,distance) VALUES("David", "Currier", "Verified","11 April 200", "Placeholder", "Classified"
, "image\/will2.jpg", "davidcurrier2@gmail.com","image\/cake.jpg","cake","It is cake","1 mile")');
*/
echo $pdo->lastInsertId();

//modify

$pdo->query('UPDATE user SET firstname="George" WHERE ID=6');

//delete
$pdo->query('DELETE FROM user WHERE ID=6');