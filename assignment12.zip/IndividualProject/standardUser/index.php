<?php






echo '<h1> Welcome to User Page</h1>';

echo '<a href="../user/create.php">Create User</a> <br><br>';

echo '<a href="../user/create.php">Edit User</a> <br><br>';


