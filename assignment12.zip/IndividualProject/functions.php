<?php


function jsonToArray(string $file) {
	return json_decode(file_get_contents($file), true);
}

function navBar(){
	echo '
		
		<nav class="navbar navbar-expand-lg navbar-light bg-light" color ="checked">
		
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="auth/signin.php">Login</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="auth/signup.php">Signup</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="admin/index.php">Admin</a>
				</li>
				
				<li class="nav-item">
					<a class="nav-link" href="manager/index.php">Manager</a>
				</li>
				
				<li class="nav-item">
					<a class="nav-link" href="standardUser/index.php">Standard User</a>
				</li>
				<li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Sort
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					<a class="dropdown-item" href="#">by distance</a>
					<a class="dropdown-item" href="#">by rating</a>
					</div>
				</li>
			</ul>
				<form class="form-inline my-2 my-lg-0">
					<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
					<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
				</form>
		</div>
		
		</nav> 
		<br>
		<br>';	
}


function showItems($id, $food_name, $user_name, $profile_picture = 'image/will2.jpg', $food_picture = 'image/cake.jpg', $email, $body = null) {
echo '
			<div class="media">
				<img src="'.$food_picture.'" class="mr-3" alt="'.$food_name.', '.$user_name.'" width="96">
				<div class="media-body">
					<h5 class="mt-0">'.$food_name.'</h5>
					
					<p class="text-muted">by <a href="user/profile.php?id='.$id.'"><img class = "profilepic" src=" '.$profile_picture.' " width="50" />'.$user_name.' </a></p>';
					
					/* TODO: include this function as a star rating
					$rating = 0;
					for($j=1; $j<6; $j++){
						if (($members[$i]['star_rating'.$j]) == 'fa fa-star checked'){
						$rating++;}
					echo '<span class="'.$members[$i]['star_rating'.$j].'"></span>' ;
					} 
					echo '&nbsp &nbsp ('.$rating . ')';
					
					*/
					
					echo '&nbsp &nbsp <a href="item/item.php?id='.$id.'">View Item</a> &nbsp &nbsp
					
					
					
					<a href="mailto:'.$email.'" target="_top">Reserve</a>
				</div>
			</div>';
}




?>