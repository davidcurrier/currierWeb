<?php 

class readWrite
{
	//function to read a file
	public function read($fileName)
	{
		//if file does not exist return nothing
		if(!file_exists($fileName)){
			return;
		}
		
		$h = fopen($fileName, 'r');
		$res = "";
		while(!feof($h))
		{
			$line = fgets($h);
			$res = $res.$line;
		}
		fclose($h);
		
	}
	
	public function write($fileName, $info)
	{
		//if file does not exist return nothing
		if(!file_exists($fileName)){
			return;
		}
		
		$h = fopen($fileName, 'w+');

		file_put_contents($h,$info);
	}
	
}