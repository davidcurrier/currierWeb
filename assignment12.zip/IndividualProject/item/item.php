<?php

$companyName = 'Food Santa';
//require_once('data.php');
//$memberList = file_get_contents ('data.json');
//$members = json_decode($memberList,true);

function jsonToArray(string $file) {
	return json_decode(file_get_contents($file), true);
}

$members = jsonToArray('../data.json');

if(!isset($_GET['id'])){
	echo 'Please enter the id of a member or visit the <a href="../index.php">index page</a>.';
	die();
}
if($_GET['id']<0 || $_GET['id']>count($members)-1){
	echo 'Please enter the id of a member or visit the <a href="../index.php">index page</a>.';
	die();
}

require('../header.php');

?>

		<?php
		
		echo '<h1>'.$members[$_GET['id']]['food_name'].'</h1>';
		
		
		echo '
		<p>'.$members[$_GET['id']]['food_description'].'</p>
		<h5 a >by '.$members[$_GET['id']]['firstname'].' '.$members[$_GET['id']]['lastname'].'</h5>
		<img class = "profilepic" src="'.$members[$_GET['id']]['food_picture'].' " width="500" />
		<p> Distance: '.$members[$_GET['id']]['distance'].' </p>
		<p> Pickup Location: '.$members[$_GET['id']]['location'].' </p>';
		
		require ('../footer.php');
		
		?>
	