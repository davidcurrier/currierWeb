<?php
$companyName = 'Food Santa';

$members=[
	[
		'firstname'=>'Will',
		'lastname'=>'Sie',
		'date_of_birth'=>'18 May 1980',
		'bio'=>'Will Sie is a passionte home chef who is ServSafe Food Handler certified and has 15 years of of work experience in the Foodservice industry',
		'location'=>'22 Woodland Hills Dr. #8, Southgate, KY',
		'profile_picture'=>'image/will2.jpg',
		'email'=>'siew1@mymail.nku.edu',
		'food_picture'=>'image/cake.jpg',
		'food_name'=> 'Double Chocolate Espresso Cake',
		'food_description'=>'a slice of double chocolate espresso cake, Frozen, eat by 2/05/2020',
		'distance'=>'5 mile(s)',
		'status'=>'Not Verified',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star checked',
		'star_rating5'=>'fa fa-star'
	],
	[
		'firstname'=>'Gordon',
		'lastname'=>'Ramsay',
		'date_of_birth'=>'8 November 1966',
		'bio'=>'Internationally renowned, multi-Michelin starred chef Gordon Ramsay has opened a string of successful restaurants across the globe, from the UK and France to Singapore and Hong Kong, to the United States. Gordon has also become a star of the small screen both in the UK and internationally, with shows such as Kitchen Nightmares, Hell’s Kitchen, Hotel Hell and MasterChef US.',
		'profile_picture'=>'image/gordonramsay.jpg',
		'email'=>'gordonenquiries@gordonramsay.com',
		'food_picture'=>'https://pbs.twimg.com/media/DH8PLn2XkAAX6YO.jpg:large',
		'food_name'=>'Best Beef Wellington!',
		'food_description'=>'savory, tender Beef Wellington fresh out of the oven - family recipe ! cook date 1/27/2020',
		'distance'=>'2 mile(s)',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star checked',
		'star_rating5'=>'fa fa-star checked'
	],
	[
		'firstname'=>'Kroger',
		'lastname'=>'Pickup',
		'date_of_birth'=>'1883',
		'bio'=>'Pickup is an online ordering service from Kroger. Now you can shop online for the products you need and pick up your order at the store from the convenience of your car! Our Associates will even bring out your order and load it into your car.',
		'profile_picture'=>'image/kroger.jpg',
		'email'=>'Stocktransfer@eq-us.com',
		'food_picture'=>'https://www.kroger.com/product/images/medium/front/0000000004011',
		'food_name'=>'Banana',
		'food_description'=>'1 ready to eat, organic Bananas - shelf life 5 days starting 1/29/2020',
		'distance'=>'1 mile(s)',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star checked',
		'star_rating4'=>'fa fa-star',
		'star_rating5'=>'fa fa-star'
	],
	[
		'firstname'=>'Selena',
		'lastname'=>'Gomez',
		'date_of_birth'=>'22 July 1992',
		'bio'=>'Actress and singer Selena Gomez was born on July 22, 1992 in Grand Prairie, Texas. She is the daughter of Mandy Teefey and Ricardo Gomez. Her mother is of part Italian ancestry, and her father is of Mexican descent. She was named after Tejano singer, Selena.',
		'profile_picture'=>'https://www.usmagazine.com/wp-content/uploads/2018/02/selena-gomez-twitter-2010.jpg?w=1000',
		'email'=>'selenagomez@hollywoodrecords.com',
		'food_picture'=>'https://cdn.vox-cdn.com/thumbor/xYTHdUTKDeo4x_B6wT5-EzmdcVc=/0x0:5472x3648/1220x813/filters:focal(2299x1387:3173x2261):format(webp)/cdn.vox-cdn.com/uploads/chorus_image/image/65747830/shutterstock_1413240503.0.jpg',
		'food_name'=>'In-N-Out Burgers',
		'food_description'=>'5 burgers - animal style, fresh by 1/30/2020, Bieber ordered too many for our date night !',
		'distance'=>'2 mile(s)',
		'star_rating1'=>'fa fa-star checked',
		'star_rating2'=>'fa fa-star checked',
		'star_rating3'=>'fa fa-star',
		'star_rating4'=>'fa fa-star',
		'star_rating5'=>'fa fa-star'
	]
];

?>