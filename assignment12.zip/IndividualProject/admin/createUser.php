
<?php
header('../user/create.php');
require_once('../json.php');

echo '<h1> Create User </h1>';
if(!count($_POST) == 0 )
{
	
$settings=[
	'host'=>'localhost',
	'db'=>'individualproject',
	'user'=>'root',
	'password'=>''
];

$opt=[
	PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
	PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
	PDO::ATTR_EMULATE_PREPARES=>false,
];
$pdo = new PDO('mysql:host='.$settings['host'].';dbname='.$settings['db'].';charset=utf8mb4',$settings['user'],$settings['password']);


$pdo->query('INSERT INTO user(firstname,lastname,status,dateofbirth,bio,location,profilepic,
email,foodpic,foodname,fooddescription,distance) VALUES('.$_POST["firstname"].','.$_POST["lastname"].','.$_POST["status"].','.$_POST["date_of_birth"].','.$_POST["bio"].', '.$_POST["location"].'
, '.$_POST["profile_picture"].','.$_POST["email"].','.$_POST["food_picture"].','.$_POST["food_name"].','.$_POST["food_description"].','.$_POST["distace"].')');
}
else
{
?>
<html>
<form action="create.php" method="POST">
First Name
<input type="text" name="firstname"><br>
Last Name
<input type="text" name="lastname"><br>
Status
<input type="text" name="status"><br>
Date of Birth
<input type="text" name="date_of_birth"><br>
Bio
<input type="text" name="bio"><br>
Location
<input type="text" name="location"><br>
Profile Picture
<input type="text" name="profile_picture"><br>
Email
<input type="text" name="email"><br>
Food Picture
<input type="text" name="food_picture"><br>
Food Name
<input type="text" name="food_name"><br>
Food Description
<input type="text" name="food_description"><br>
Distace
<input type="text" name="distace"><br>

<button type="submit" value="Submit">Submit</button>
</form>
</html>
<?php
}
require('../footer.php');

?>