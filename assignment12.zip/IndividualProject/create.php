<?php
// REQUIRE JSON LIBRARY require_once('json.php');

// CHECK IF THERE IS SOME DATA IN POST
// IF SO, writeJSON('profile.json',$_POST);
// ELSE DISPLAY FORM BELOW

require ('header.php');
$title = 'Food Santa';
echo '<h1 class="headlines">'.$title.'<img src ="image/logofinal.png" width="200"> </h1>';
printHeader($title);
?>


	
<form action="create.php" method="POST">
	<label for="firstname">First Name:</label><br>
	<input type="text" id="firstname" name="firstname" value=""><br>
	<label for="lastname">Last name:</label><br>
	<input type="text" id="lastname" name="lastname" value=""><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password" value=""><br>
	<label for="date_of_birth">Date of Birth:</label><br>
	<input type="datetime-local" id="date_of_birth" name="date_of_birth" value=""><br>
	<label for="location">Location:</label><br>
	<input type="text" id="location" name="location" value=""><br>
	<label for="email">Email:</label><br>
	<input type="email" id="email" name="email" value=""><br>
	<label for="bio">About you:</label><br>
	<textarea rows="5" cols="49" type="text" id="bio" name="bio" value=""></textarea><br>
	<input type="submit" value="Submit">

</form>

<?php
		require('footer.php');
?>