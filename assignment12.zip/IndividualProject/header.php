<?php

function printHeader($title){

	?>

<!doctype html>
<html lang="en">
	<head>
	
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<!-- Add icon library for star rating-->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
		<!-- This is the CSS for input form -->
		<link rel="stylesheet" href="css/style.css">
		<style>
		
		.headlines {font-family:georgia, serif;
					color:#381704;
					font-size:50px;
					letter-spacing:0.1em;
					line-height:200%;
					padding-top:11px;
					text-align:center;
					}
					
		.checked	{color:orange;}
		body		{
					background-image: linear-gradient(to top, #e6e9f0 0%, #eef1f5 100%);
					}
		.profilepic {
					align: center;
					max-width: 30%;
					height: auto;
					border-radius: 50%;
					padding: 20px 10px 20px 10px;
					}
		
		</style>
		<title><?=$title?></title>
	</head>
	<body>
	<div class="container">
	
	<?php
	  
}