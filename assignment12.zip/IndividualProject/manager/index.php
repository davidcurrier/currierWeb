<?php


session_start();

if($_SESSION['userid'] != 'curriedc@mail.uc.edu')
{
	die('You are not a manager, please leave this page.');
	
}

echo '<h1> Welcome to Manager Page</h1>';

echo '<a href="../user/create.php">Create User</a> <br><br>';

echo '<a href="../user/create.php">Edit User</a> <br><br>';


