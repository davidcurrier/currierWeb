<?php
session_start();
include ('functions.php');
$members = jsonToArray('data.json');
$title = 'Food Santa';

require ('header.php');

printHeader($title);
?>


		<?php   
		echo '<h1 class="headlines">'.$title.'<img src ="image/logofinal.png" width="200"> </h1>';
		navBar();
		for($i=0;$i<count($members);$i++){
			showItems($i, $members[$i]['food_name'], $members[$i]['firstname'].' '.$members[$i]['lastname'], $members[$i]['profile_picture'], $members[$i]['food_picture'], $members[$i]['email']);
			
			if(isset($_SESSION['userid']))
			{
			echo '<a href="">Like Post</a>';
			}
			echo '<hr>';
		}
		
			require('footer.php');
		?>
		
	